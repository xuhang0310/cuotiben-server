# 图片压缩工具 - 快速部署指南

> 专为国内用户编写的零经验部署指南

## 前置要求

| 组件 | 要求 | 说明 |
|------|------|------|
| Python | 3.11 或 3.12 | LaMa深度学习需要，基础功能可用3.8+ |
| 磁盘空间 | 2GB+ | 包含模型文件 |
| 内存 | 4GB+ | 推荐8GB |

---

## 方式一：Docker 部署（最简单 ⭐）

### 适用于
- 完全零基础用户
- Windows / Mac / Linux 均可
- 不想配置环境的用户

### 步骤

**Windows 用户**：
```bash
1. 安装 Docker Desktop：https://www.docker.com/products/docker-desktop
2. 双击运行：start-docker.bat
3. 等待3分钟，浏览器自动打开
```

**Mac/Linux 用户**：
```bash
1. 安装 Docker
2. 给脚本执行权限：chmod +x start-docker.sh
3. 运行：./start-docker.sh
```

---

## 方式二：Windows 安装（推荐 ⭐⭐）

### 适用于
- Windows 10/11 用户
- 日常办公使用

### 步骤

**方法一：一键安装（推荐）**
```bash
1. 双击运行：install-windows.bat
2. 按提示安装 Python 3.11
3. 等待依赖安装完成
4. 启动服务
```

**方法二：手动安装**
```bash
1. 安装 Python 3.11：https://www.python.org/downloads/
   ⚠️ 勾选 "Add Python to PATH"

2. 配置国内镜像：
   pip config set global.index-url https://pypi.tuna.tsinghua.edu.cn/simple

3. 安装依赖：
   pip install -r requirements.txt

4. 启动服务：
   双击 "双击启动.bat"
```

---

## 方式三：CentOS 服务器部署（⭐⭐⭐）

### 适用于
- 服务器部署
- 长期运行
- 多人共享使用

### 步骤

```bash
# 1. 上传 install-centos.sh 到服务器

# 2. 运行安装脚本
chmod +x install-centos.sh
sudo bash install-centos.sh

# 3. 按提示上传项目文件
scp -r image_compress_web/* root@服务器IP:/opt/image-tools/

# 4. 完成安装后，服务自动启动
# 访问：http://服务器IP:8000
```

---

## 网络加速配置

### pip 国内镜像（必选）

```bash
# 清华镜像（推荐）
pip config set global.index-url https://pypi.tuna.tsinghua.edu.cn/simple

# 或阿里云
pip config set global.index-url https://mirrors.aliyun.com/pypi/simple/
```

### Docker 镜像加速

```json
// Docker Desktop -> Settings -> Docker Engine
{
  "registry-mirrors": [
    "https://docker.mirrors.ustc.edu.cn",
    "https://hub-mirror.c.163.com"
  ]
}
```

---

## LaMa 深度学习模型安装（可选）

**要求 Python 3.11 或 3.12**（3.13不支持）

```bash
# 1. 确认 Python 版本
python --version  # 应显示 3.11.x

# 2. 安装 PyTorch
pip install torch torchvision --index-url https://download.pytorch.org/whl/cpu

# 3. 安装 LaMa-cleaner
pip install lama-cleaner

# 4. 验证
python -c "from lama_inpainting import load_model; print('OK')"
```

**首次使用会自动下载模型**（约500MB）

---

## 常见问题

### Q: pip 安装超时怎么办？
**A**: 确保已配置国内镜像，或使用手机热点

### Q: Windows 提示 "python" 不是命令？
**A**: 重新安装 Python，**必须勾选 "Add Python to PATH"**

### Q: 端口 8000 被占用？
**A**:
```bash
# 查找占用进程
netstat -ano | findstr :8000

# 或修改 backend.py 中的端口
# 搜索 "8000" 改为其他端口如 "8080"
```

### Q: 如何更新代码？
**A**:
```bash
# Docker
docker-compose down
docker-compose up -d --build

# 普通部署
git pull  # 如果用git
pip install -r requirements.txt  # 更新依赖
```

---

## 文件说明

| 文件 | 用途 |
|------|------|
| `start-docker.bat` | Windows Docker 一键启动 |
| `start-docker.sh` | Mac/Linux Docker 一键启动 |
| `install-windows.bat` | Windows 完整安装向导 |
| `双击启动.bat` | Windows 快速启动（安装后使用）|
| `install-centos.sh` | CentOS 服务器安装脚本 |
| `Dockerfile` | Docker 镜像构建配置 |
| `docker-compose.yml` | Docker 服务编排配置 |
| `docs/DEPLOYMENT_GUIDE.md` | 详细部署文档 |

---

## 技术支持

- 项目文档：`docs/DEPLOYMENT_GUIDE.md`
- 日志查看：`app.log` 或 `docker-compose logs -f`
- 端口：默认 8000

**建议新手使用 Docker 方案，最省心！**
